﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_7.Classes.Data
{
    public class ItemData
    {
        public string name { get; set; }
        public string id { get; set; }
    }
}
