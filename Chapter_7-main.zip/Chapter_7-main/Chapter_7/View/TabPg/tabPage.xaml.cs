namespace Chapter_7.View.TabbedPage;

public partial class tabPage : ContentPage
{
	public tabPage()
	{
		InitializeComponent();
	}
}