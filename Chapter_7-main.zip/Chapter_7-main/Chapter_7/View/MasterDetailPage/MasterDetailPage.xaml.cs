namespace Chapter_7.View.MasterDetailPage;

public partial class MasterDetailPage : ContentPage
{
	public MasterDetailPage()
	{
		InitializeComponent();
	}
}