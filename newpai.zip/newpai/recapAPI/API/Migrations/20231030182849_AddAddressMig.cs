﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace API.Migrations
{
    /// <inheritdoc />
    public partial class AddAddressMig : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "addressid",
                table: "Users",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "AddressUser",
                columns: table => new
                {
                    id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    postcode = table.Column<string>(type: "TEXT", nullable: true),
                    address = table.Column<string>(type: "TEXT", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AddressUser", x => x.id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Users_addressid",
                table: "Users",
                column: "addressid");

            migrationBuilder.AddForeignKey(
                name: "FK_Users_AddressUser_addressid",
                table: "Users",
                column: "addressid",
                principalTable: "AddressUser",
                principalColumn: "id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Users_AddressUser_addressid",
                table: "Users");

            migrationBuilder.DropTable(
                name: "AddressUser");

            migrationBuilder.DropIndex(
                name: "IX_Users_addressid",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "addressid",
                table: "Users");
        }
    }
}
