﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace API.Migrations
{
    /// <inheritdoc />
    public partial class UserConfigMig : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Users_AddressUser_addressid",
                table: "Users");

            migrationBuilder.DropIndex(
                name: "IX_Users_addressid",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "addressid",
                table: "Users");

            migrationBuilder.AlterColumn<int>(
                name: "id",
                table: "Users",
                type: "INTEGER",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "INTEGER")
                .OldAnnotation("Sqlite:Autoincrement", true);

            migrationBuilder.AddForeignKey(
                name: "FK_Users_AddressUser_id",
                table: "Users",
                column: "id",
                principalTable: "AddressUser",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Users_AddressUser_id",
                table: "Users");

            migrationBuilder.AlterColumn<int>(
                name: "id",
                table: "Users",
                type: "INTEGER",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "INTEGER")
                .Annotation("Sqlite:Autoincrement", true);

            migrationBuilder.AddColumn<int>(
                name: "addressid",
                table: "Users",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Users_addressid",
                table: "Users",
                column: "addressid");

            migrationBuilder.AddForeignKey(
                name: "FK_Users_AddressUser_addressid",
                table: "Users",
                column: "addressid",
                principalTable: "AddressUser",
                principalColumn: "id");
        }
    }
}
