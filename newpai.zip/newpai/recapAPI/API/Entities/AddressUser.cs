public class AddressUser:BasicUser
{
    public string postcode { get; set; }
    public string address { get; set;}
}