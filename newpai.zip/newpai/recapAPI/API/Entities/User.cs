namespace API;
public class User:BasicUser
{
    public string name {get; set;}
    public AddressUser address{get; set;}
}
