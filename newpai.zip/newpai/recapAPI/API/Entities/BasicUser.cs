public class BasicUser
{
    public int id { get; set; }
}