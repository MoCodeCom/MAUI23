using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using API.Data;
using API.Specification;
using Microsoft.EntityFrameworkCore;
using SQLitePCL;

namespace API.GenericRepository
{
    public class UserGenericRepository<T> : IUserGenericRepository<T> where T : BasicUser
    {
        private readonly UserDbContext _context;

        public UserGenericRepository(UserDbContext context)
        {
            _context = context;
        }
        public async Task<IReadOnlyList<T>> GetAllUsersAsync()
        {
            return await _context.Set<T>().ToListAsync();
        }


        public async Task<T> GetUserByIdAsync(int id)
        {
            return await _context.Set<T>().FindAsync(id);
        }
        /*----------specification--------------------------*/
        public async Task<T> GetEntityWithSpec(ISpecification<T> spec)
        {
            return await ApplySpecification(spec).FirstOrDefaultAsync();
        }

        public async Task<IReadOnlyList<T>> GetListEntityWithSpec(ISpecification<T> spec)
        {
            return await ApplySpecification(spec).ToListAsync();
        }


        /*IQureable for specificaiton pattern*/
        protected IQueryable<T>ApplySpecification(ISpecification<T>spec)
        {
            return SpecificationEvaluator<T>.GetQuery(
                _context.Set<T>().AsQueryable(),
                spec
            );
        }
    }
}