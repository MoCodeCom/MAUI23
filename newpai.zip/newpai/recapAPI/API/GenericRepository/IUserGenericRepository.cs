using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using API.Specification;


namespace API.GenericRepository
{
    public interface IUserGenericRepository<T> where T: BasicUser
    {
        Task<T>GetUserByIdAsync(int id);
        Task<IReadOnlyList<T>> GetAllUsersAsync();

        /*Specificaiton pattern*/
        Task<T>GetEntityWithSpec(ISpecification<T>spec);
        Task<IReadOnlyList<T>>GetListEntityWithSpec(ISpecification<T>spec);
    }
}