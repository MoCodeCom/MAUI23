using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using API.DTOs;
using AutoMapper;

namespace API.Mapper
{
    public class Mappers:Profile
    {
        public Mappers()
        {
            CreateMap<User, UserDtos>()
            .ForMember(u=>u.address, o=>o.MapFrom(s=>s.address.postcode))
            .ReverseMap();


            CreateMap<User, UserAddressDtos>().ReverseMap();
        }

        
    }
}