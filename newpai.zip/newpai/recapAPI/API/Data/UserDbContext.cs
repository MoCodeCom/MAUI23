using System.Reflection;
using Microsoft.EntityFrameworkCore;

namespace API.Data;
public class UserDbContext:DbContext
{
    public UserDbContext(DbContextOptions options):base(options){}

    public DbSet<User> Users{get; set;}
    public DbSet<AddressUser> AddressUser{get; set;}

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
    }

}