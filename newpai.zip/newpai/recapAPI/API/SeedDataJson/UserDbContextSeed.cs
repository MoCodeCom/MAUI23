using System.Text.Json;
using API;
using API.Data;

public class UserDbContextSeed
{
    public static async Task SeedAsync(UserDbContext context)
{
    if(!context.Users.Any())
    {
        var UserData = File.ReadAllText("SeedDataJson/UserJson.json");
        var users = JsonSerializer.Deserialize<List<User>>(UserData);
        context.Users.AddRange(users);
    }


    if(!context.AddressUser.Any())
    {
        var AddressUserData = File.ReadAllText("SeedDataJson/AddressUserJson.json");
        var addressusers = JsonSerializer.Deserialize<List<AddressUser>>(AddressUserData);
        context.AddressUser.AddRange(addressusers);
    }

    if(context.ChangeTracker.HasChanges())await context.SaveChangesAsync();

}
}


