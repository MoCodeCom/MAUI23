using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace API.Specification
{
    public class Specification<T> : ISpecification<T>
    {
        public Specification()
        {
            /*
            Empty constroctor for call Specificatoin in UserWithAddressSpec class.
            */
        }

        public Specification(Expression<Func<T, bool>> criteria)
        {
            Criteria = criteria;
        }
        public Expression<Func<T, bool>> Criteria {get;}



        // Maybe the list is null.
        public List<Expression<Func<T, object>>> Includes {get;} 
         = new List<Expression<Func<T,object>>>();


         protected void AddInclude(Expression<Func<T, object>> includeExpression)
         {
            Includes.Add(includeExpression);
         }
    }
}