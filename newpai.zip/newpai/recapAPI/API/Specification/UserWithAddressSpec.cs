using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Specification
{
    public class UserWithAddressSpec:Specification<User>
    {
        public UserWithAddressSpec()
        {
            AddInclude(x => x.address);
        }

        public UserWithAddressSpec(int id):base(x => x.id == id)
        {
            AddInclude(x => x.address);
        }
    }
}