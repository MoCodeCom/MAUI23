using API;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

public class UserConfig : IEntityTypeConfiguration<User>
{
    //This inherent class to configuration data.
    public void Configure(EntityTypeBuilder<User> builder)
    {
        builder.Property(u => u.id).IsRequired();
        builder.Property(u => u.name).HasMaxLength(75);
        builder.HasOne(u => u.address).WithMany().HasForeignKey(u => u.id);
    }
}