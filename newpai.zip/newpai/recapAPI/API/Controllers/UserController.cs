using API.Data;
using API.DTOs;
using API.GenericRepository;
using API.Specification;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace API.Controllers;


public class UserController:BaseApiController
    {
    private readonly IUserGenericRepository<User> _userContext;
    private readonly IUserGenericRepository<AddressUser> _addressContext;
    private readonly IMapper _mapper;

    //private readonly IUserRpository _repo;
    //private readonly UserDbContext _db;

    public UserController(
        /*UserDbContext db*/
        /*IUserRpository repo*/
        IUserGenericRepository<User> userContext,
        IUserGenericRepository<AddressUser> addressContext,
        IMapper mapper
        )
        {
            //_db = db;
            //_repo = repo;
            _userContext = userContext;
            _addressContext = addressContext;
            _mapper = mapper;
        }

        [HttpGet]
        public async Task<ActionResult<IReadOnlyList<UserDtos>>> GetAllUsers(){
            //var users = await _db.Users.ToListAsync();
            //return users;
            //return Ok(await _repo.GetAllUsersAsync());
            var spec = new UserWithAddressSpec();
            var users = await _userContext.GetListEntityWithSpec(spec);
            //return Ok(await _userContext.GetAllUsersAsync());
            
            //return Ok(users);
            /*
            //without auto mapper
            return users.Select( u => new UserDtos{
                name = u.name,
                address = u.address.address
            }).ToList();*/

            return Ok(_mapper.Map<IReadOnlyList<User>,IReadOnlyList<UserDtos>>(users));
        }
        [HttpGet("useraddress")]
        public async Task<ActionResult<IReadOnlyList<UserAddressDtos>>> GetAllUsersAddress(){
            //var users = await _db.Users.ToListAsync();
            //return users;
            //return Ok(await _repo.GetAllUsersAsync());
            var spec = new UserWithAddressSpec();
            var users = await _userContext.GetListEntityWithSpec(spec);
            //return Ok(await _userContext.GetAllUsersAsync());
            
            //return Ok(users);
            /*
            //without auto mapper
            return users.Select( u => new UserDtos{
                name = u.name,
                address = u.address.address
            }).ToList();*/

            return Ok(_mapper.Map<IReadOnlyList<User>,IReadOnlyList<UserAddressDtos>>(users));
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<UserDtos>> GetUser(int id)
        {
            //return await _db.Users.FindAsync(id);
            //return await _repo.GetUserByIdAsync(id);
            //return await _userContext.GetUserByIdAsync(id);

            var spec = new UserWithAddressSpec();
            var user = await _userContext.GetEntityWithSpec(spec);
            //return Ok(user);

            return Ok(_mapper.Map<User,UserDtos>(user));
        }

        [HttpGet("address")]
        public async Task<ActionResult<IEnumerable<User>>> GetAllAddressUsers(){
            //var users = await _db.Users.ToListAsync();
            //return users;
            //return Ok(await _repo.GetAllAddressUsersAsync());
            return Ok(await _addressContext.GetAllUsersAsync());
        }

        
    }

