using API;
using API.Data;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;

public class UserRepository : IUserRpository
{
    private readonly UserDbContext _db;

    public UserRepository(UserDbContext db)
    {
        _db = db;
    }

    /*
    public async Task<AddressUser> GetAddressUserByIdAsync(int id)
    {
        return await _db.AddressUser.FindAsync(id);;
    }*/

    public async Task<IReadOnlyList<AddressUser>> GetAllAddressUsersAsync()
    {
        return await _db.AddressUser.ToListAsync();
    }

    public async Task<IReadOnlyList<User>> GetAllUsersAsync()
    {
        return await _db.Users
        .Include(p => p.address)
        .ToListAsync();
    }

    public async Task<User> GetUserByIdAsync(int id)
    {
        return await _db.Users
        .Include(p => p.address)
        //.FindAsync(id);
        .FirstOrDefaultAsync(u => u.id == id);
    }
}