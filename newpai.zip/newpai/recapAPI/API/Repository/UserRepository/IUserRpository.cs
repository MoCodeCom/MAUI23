using API;

public interface IUserRpository
{
    Task<User>GetUserByIdAsync(int id);
    Task<IReadOnlyList<User>>GetAllUsersAsync();
    //Task<AddressUser>GetAddressUserByIdAsync(int id);
    Task<IReadOnlyList<AddressUser>>GetAllAddressUsersAsync();
}