using API.Data;
using API.Errors;
using API.GenericRepository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.FileProviders;
using Microsoft.VisualBasic;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<UserDbContext>(opt => opt.UseSqlite(builder.Configuration.GetConnectionString("DefaultConnection")));
builder.Services.AddScoped<IUserRpository, UserRepository>();
builder.Services.AddScoped(typeof(IUserGenericRepository<>), typeof(UserGenericRepository<>));;
/*----- Mapper -----*/
builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
/*------------------*/
var app = builder.Build();
// Configuer the HTTP controller to redirect to error controller
app.UseMiddleware<ExceptionMiddleware>();
app.UseStatusCodePagesWithReExecute("/error/{0}");
//to lead an possible error from behavior [] to message
/*
builder.Services.Configure<ApiBehaviorOptions>(options =>
{
    options.InvalidModelStateResponseFactory = actionContext => 
    {
        var errors = actionContext.ModelState
        .Where(e =>e.Value.Errors.Count > 0)
        .SelectMany(x => x.Value.Errors)
        .Select(x => x.ErrorMessage).ToArray();

        var errorResponse = new ApiValidationErrorResponse
        {
            Errors = errors
        };

        return new BadRequestObjectResult(errorResponse);
    };
});
*/
// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

//app.UseHttpsRedirection();
//cors problem in frontend
app.UseCors(options => options.AllowAnyOrigin());
//To call static file such as images or fornt end.
app.UseStaticFiles();

// call static specific file out of wwwroot file such as images.
app.UseStaticFiles(new StaticFileOptions{
    FileProvider = new PhysicalFileProvider(Path.Combine(Directory.GetCurrentDirectory(), "Content")),RequestPath = "/Content"
});
/*----------------------------------------------*/
app.UseAuthorization();

app.MapControllers();
//when dont now the controller redirct to:
app.MapFallbackToController("Index","Fallback");
//To let migrations happen auto update when make any possible chane on database
using var scope = app.Services.CreateScope();
var services = scope.ServiceProvider;
var context = services.GetRequiredService<UserDbContext>();//to implement context when migrations
var logger = services.GetRequiredService<ILogger<Program>>();//for errors
try
{
    await context.Database.MigrateAsync();
    await UserDbContextSeed.SeedAsync(context);
}catch(Exception ex)
{
    logger.LogError(ex,"An error occoured during migration");
}
app.Run();
